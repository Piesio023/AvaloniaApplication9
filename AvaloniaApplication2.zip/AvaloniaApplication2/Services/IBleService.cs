namespace AvaloniaApplication2.Services;

public interface IBleService
{
    void StartServer();
    public void BleServer_SendNotification(string message);
    public void StopServer();
    string Status { get; }
}