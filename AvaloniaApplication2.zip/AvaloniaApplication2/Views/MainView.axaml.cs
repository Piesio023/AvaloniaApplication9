using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using AvaloniaApplication2.Services;
using static System.Net.Mime.MediaTypeNames;


namespace AvaloniaApplication2.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }

    private void ButtonHello_Click(object? sender, RoutedEventArgs e)
    {
        // Odwo�anie bezpo�rednie
        var bleService = AvaloniaApplication2.App.BleService;

        if (bleService != null)
        {
            bleService.StartServer();
            MainText.Text = bleService.Status;
        }
        else
        {
            MainText.Text = "Us�uga BLE nie zosta�a za�adowana.";
        }
    }
    private void Button_Click(object? sender, RoutedEventArgs e)
    {
        // Odwo�anie bezpo�rednie
        var bleService = AvaloniaApplication2.App.BleService;

        if (bleService != null)
        {
            bleService.BleServer_SendNotification($"{test.Text}");
        }
        
    }
    private void Button_Click_stop(object? sender, RoutedEventArgs e)
    {
        // Odwo�anie bezpo�rednie
        var bleService = AvaloniaApplication2.App.BleService;

        if (bleService != null)
        {
            bleService.StopServer();
        }

    }
}